import UIKit
import Capacitor

/// 把网页的 WKWebView「接听」口打开：网页里 window.webkit.messageHandlers.petIsland.postMessage(...)
/// 会走到 PetIslandScriptHandler → 更新灵动岛
/// 用法：在 Xcode 的 Main.storyboard 里，把根 View Controller 的 Custom Class 改成 PetIslandViewController
class PetIslandViewController: CAPBridgeViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        if let webView = self.webView {
            webView.configuration.userContentController.add(
                PetIslandScriptHandler(),
                name: "petIsland"
            )
        }
    }
}
