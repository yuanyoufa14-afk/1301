import ActivityKit
import Foundation

/// 灵动岛「实时活动」的内容定义（App 与 Widget 两个 Target 共用这一个文件）
/// 静态部分：这次活动是什么宠物
/// 动态部分（ContentState）：爱心值、最近动作——每次喂食/玩耍后更新
struct PetActivityAttributes: ActivityAttributes {

    public struct ContentState: Codable, Hashable {
        var petName: String   // 宠物名，如「小猫」
        var emoji: String     // 头像 emoji，如 🐱
        var love: Int         // 当前爱心值
        var action: String    // 最近动作，如「喂食了」
    }

    var petName: String
    var emoji: String
}
