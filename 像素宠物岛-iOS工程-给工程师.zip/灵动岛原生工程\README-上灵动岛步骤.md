# 像素宠物岛 · 上「苹果灵动岛」原生工程

> 2026-08-21 更新：玩法已升级到 **v10.2 真·灵动岛形态**（透明背景胶囊：常驻只显示
> 宠物+天气，点按加宽露出操作按钮，再按下拉完整面板；金币变动胶囊上缘浮现；
> 雨天宠物在胶囊内躲雨发抖 + 雨滴/雪花特效；含 v8 全部玩法——双人猜拳、默契问答、
> 小纸条、孔雀/夜枭传说宠物、性格喜好喂食、成就墙、每日签到 7 日礼）。
> 本工程上线时请使用最新的 `pet-island-v2.html` 作为 `www/index.html` 的内容来源
> （运行 `node _gen_www.js` 自动生成并注入灵动岛桥接代码，当前 www/ 已是最新 v10.2）。

把现在的**网页版宠物岛**打包成一个**真正的 iPhone App**，再通过苹果的「实时活动」
功能把你的宠物**放到灵动岛上**（小图标 + 爱心值 + 最近动作）。

> 重要预期：灵动岛是「卡片式」显示，**不是**动画宠物常驻。
> 效果 = 灵动岛小胶囊里出现宠物头像 + ❤️爱心值，喂食/玩耍后数字实时更新。
> 这是苹果系统允许的全部，任何 App 都一样。

---

## 你需要准备（绕不开的门槛）

| 需要 | 说明 | 钱 |
|---|---|---|
| 一台 **Mac**（苹果电脑） | iOS 只能 Mac 上编译；没有可租「云 Mac」（约几十元/月） | 0 或租 |
| **Xcode**（App Store 免费下载） | 苹果官方开发工具，比较大，要下载一会儿 | 0 |
| **苹果开发者账号** | 个人版，一年 ¥688 左右（$99）；不买的话每 7 天要重装一次，不推荐小白 | 约 ¥688/年 |
| **iPhone** | 必须 **iPhone 14 Pro/Pro Max 或 iPhone 15 全系**（有灵动岛的机型）；13 及更早不显示 | 已有 |
| 本文件夹里的所有文件 | 你已经有了 | 0 |

全程**不用改一行网页代码**。以后想更新宠物/玩法，改 `www/` 里的文件后跑一句命令即可。

---

## 第 0 步：把整个文件夹拷到 Mac

把 `灵动岛原生工程` 这个**文件夹**（包含 www / ios-src / package.json 等）
用 U 盘、微信或网盘拷到 Mac 上，放哪个目录都行，比如 `文稿/宠物岛原生工程`。

## 第 1 步：在 Mac 上装 Node.js（只装一次）

1. 打开「终端」（Launchpad → 其他 → 终端）。
2. 输入下面命令回车，会弹窗提示装东西，输一次开机密码：
   ```
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```
   （如果你不想装 Homebrew，也可以直接去 nodejs.org 下载 LTS 版安装包双击安装）
3. 然后输入：
   ```
   brew install node
   ```
4. 验证：输入 `node -v`，能看到版本号（如 v22.x）就成功了。

## 第 2 步：生成 iOS 工程

1. 终端里进入你的工程文件夹（把下面的路径换成你自己的）：
   ```
   cd ~/文稿/宠物岛原生工程
   ```
2. 安装依赖（国内网络慢的话，可以先执行 `npm config set registry https://registry.npmmirror.com`）：
   ```
   npm install
   ```
3. 生成 iOS 工程（会自动创建 `ios/` 文件夹）：
   ```
   npx cap add ios
   ```
4. 把网页文件同步进去：
   ```
   npx cap sync ios
   ```

## 第 3 步：打开 Xcode 并添加「灵动岛小组件」

1. 终端执行（会自动打开 Xcode）：
   ```
   npx cap open ios
   ```
2. 等 Xcode 打开后，看左上角项目导航，找到 **App** 工程。
3. 菜单栏：**File → New → Target...**，搜索 **Widget Extension**，选中它点 Next。
4. 填写：
   - Product Name：`PetIslandWidget`
   - 一定要勾选 **Include Live Activity**（这是灵动岛的开关！）
   - 其它默认，点 Finish。
5. 弹出提示 "Activate PetIslandWidget scheme?" 点 **Activate**（激活，别点取消）。

## 第 4 步：放入宠物代码（替换自动生成的文件）

1. 在 Xcode 左侧导航，找到自动生成的 **PetIslandWidget** 文件夹，里面通常有 3 个文件：
   - `PetIslandWidget.swift`（静态小组件，**删掉**）
   - `PetIslandWidgetLiveActivity.swift`（模板实时活动，**删掉**）
   - `PetIslandWidgetBundle.swift`（**保留**，别动）
   删法：右键文件 → Delete → Move to Trash（如果提示引用丢失就选移除引用）。
2. 打开 Finder，进入工程文件夹里的 `ios-src` 文件夹，里面 5 个文件全部选中。
3. 把 5 个文件**拖进 Xcode** 左侧的工程导航里（拖到 App 图标那一层，让 Xcode 问你怎么放）。
4. 弹出 "Choose options" 时，**Add to targets** 请这样勾选：

   | 文件 | 要勾选的 Target |
   |---|---|
   | `PetActivityAttributes.swift` | **App** ✅ 和 **PetIslandWidget** ✅（两个都勾！） |
   | `PetIslandWidget.swift` | 只勾 **PetIslandWidget** |
   | `PixelPet.swift` | 只勾 **PetIslandWidget** |
   | `PetIslandScriptHandler.swift` | 只勾 **App** |
   | `PetIslandViewController.swift` | 只勾 **App** |

   如果放进去后发现勾错了：点中文件 → 右侧「File Inspector」→ Target Membership 里改勾选。

## 第 5 步：让网页能喊得动灵动岛（1 分钟）

1. 在 Xcode 左侧找到 **Main.storyboard**（在 App/App 文件夹里），点击它打开画布。
2. 画布上有个 View Controller，**单击选中它**（选中后周围有蓝框）。
3. 右侧顶部工具栏点**最右边那个图标**（Identity Inspector，长得像身份证）。
4. 在 **Custom Class → Class** 一栏，把 `CAPBridgeViewController` 改成：
   ```
   PetIslandViewController
   ```
   回车确认。

## 第 6 步：签名（用你的开发者账号）

1. 点 Xcode 最顶部中间的 **App** 工程（蓝色图标）→ 打开 **Signing & Capabilities**。
2. 勾选 **Automatically manage signing**。
3. **Team** 选择你的开发者账号。
4. 左边 Target 列表里再点 **PetIslandWidget**，同样设置 Team。
5. 如果提示 Bundle Identifier 冲突，随便改一下后缀（例如 `com.petisland.love.widget`）即可。

## 第 7 步：装到你 iPhone 上！🎉

1. 用数据线把 iPhone 连到 Mac。
2. 第一次连，iPhone 上要点「信任此电脑」。
3. Xcode 顶部中间，把运行设备从「Any iOS Device」改成你的 iPhone。
4. 点左上角**播放按钮 ▶**，等它编译（第一次比较久，2~5 分钟）。
5. 手机桌面出现「像素宠物岛」App，打开它：
   - 第一屏动画亮起后，**灵动岛上的宠物已经出现了** 🐱
   - 点「喂食」「玩耍」「摸摸」，灵动岛上的爱心值会**实时变化**
   - 锁屏后也能看到一张宠物卡片
6. 如果手机弹出「是否允许实时活动」→ 点**允许**。

---

## 常见问题（先看这里）

- **灵动岛没出现？** 确认手机是 iPhone 14 Pro/Pro Max 或 15 全系；模拟器**不支持**灵动岛，必须真机。
- **提示实时活动被限制？** iPhone 设置 → 像素宠物岛 → 允许「实时活动」。
- **编译报签名错？** 两个 Target（App 和 PetIslandWidget）都要选同一个 Team。
- **微信传文件到 Mac 后打不开？** 用「下载」文件夹里的原文件，别在微信缓存里运行。
- **以后改了网页想重新打包？** 只改 `www/` 里的 `index.html`，然后终端：
  ```
  npx cap sync ios
  ```
  再在 Xcode 点 ▶ 即可。

## 上架 App Store · 最省钱方案（给想让别人下载的用户）

### 花多少钱？

| 项目 | 最低成本 | 能不能省 | 说明 |
|---|---|---|---|
| **代码** | **0 元** | ✅ 已写好 | 本工程里的网页代码 + Swift 小组件代码 + 图标 = 全齐 |
| **Mac 电脑** | **0 元** | ✅ 可借/可租 | 找朋友借；或租「云 Mac」约几十元/月 |
| **编译打包** | **0 ~ 100 元** | ✅ 可找代编译 | 淘宝/闲鱼「iOS 代编译」一般几十元一次 |
| **开发者账号** | **约 ¥688/年** | ❌ **省不掉** | 苹果强制收费；用别人账号上架会有归属风险 |
| **合计** | **约 ¥688/年 + 几十元** | — | 这是自己账号上架的最低成本 |

> ⚠️ 凡是号称"完全免费上架"的，基本都是用别人账号代上架，App 名义上是人家的，风险很大，不推荐。

### 上架前，编译师傅需要你提供

1. **本工程文件夹**（完整拷给师傅）。
2. **苹果开发者账号**（你自己注册好个人账号，把账号密码或邀请师傅进团队）。
3. **App 图标**（已放在 `AppIcon/` 文件夹，全套尺寸已生成好）。
4. **隐私政策网址**（已写好，见下文；上架时填这个链接）。
5. **App 信息**：名称、副标题、关键词、简单描述、截图用的测试账号等。

### 给编译师傅的交付清单

师傅拿到本工程后，按以下顺序操作即可：

1. 按「第 0~2 步」生成 Xcode 工程（`npx cap add ios` + `npx cap sync ios`）。
2. 按「第 3 步」添加 Widget Extension，**必须勾选 Include Live Activity**。
3. 按「第 4 步」把 `ios-src/` 里 5 个文件拖进 Xcode，注意 Target 勾选。
4. 按「第 5 步」把 `Main.storyboard` 的 Class 改成 `PetIslandViewController`。
5. **添加 App 图标**：在 Xcode 左侧选 `App/Assets.xcassets/AppIcon.appiconset`，把 `AppIcon/` 里的 PNG 全部拖进去；1024x1024 那张拖到 App Store 位置。
6. **隐私政策**：把 `privacy.html` 部署到任意可访问网址，上架时填写该 URL。当前已部署的隐私政策地址为：
  ```
  https://733a9609a2e94d7e95b4a4ee78739496.app.workbuddy.link/privacy.html
  ```
  （你也可以把 `privacy.html` 放到自己的 GitHub Pages / 服务器上，只要审核员能打开即可。）
7. **设置 Bundle ID、版本号、签名 Team**，Archive 后提交 App Store Connect 审核。

### 隐私政策（已准备好）

本仓库已附带 `privacy.html`，内容是：不收集个人信息、数据存本机、双人同步仅传输匿名房间号和动作事件。上架时直接把这个 HTML 部署到一个网址（例如 GitHub Pages 或 CloudStudio），把链接填到 App Store Connect 即可。

### 审核风险提示

- **实时活动（灵动岛）** 属于较新功能，审核员会重点看你是否真的需要灵动岛。建议在审核备注里写："用户喂养宠物后，通过 Live Activity 在灵动岛和锁屏界面展示宠物状态，方便用户持续关注宠物情绪值"。
- **免费 App + 无广告 + 无内购** 通过率更高；如果你以后想加内购，需要另外配置。
- 首次上架被拒很常见，按审核意见改一句描述或补张截图再提交即可，不用慌。

## 效果图（示意图，非真实截图）

```
收起状态（灵动岛小胶囊）            展开/长按状态
┌──────────┐                    ┌──────────────────────┐
│ 🐱  ❤️78 │   ← 长按展开 →    │ 🐱  小猫             │
└──────────┘                    │     ❤️ 78  喂食了    │
                               └──────────────────────┘
（宠物头像 = PixelPet.swift 画的像素小图标，爱心值实时更新）
```

祝你们的宠物早日住进灵动岛！💕
