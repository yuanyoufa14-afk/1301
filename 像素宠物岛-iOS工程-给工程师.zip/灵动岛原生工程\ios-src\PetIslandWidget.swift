import WidgetKit
import SwiftUI
import ActivityKit

/// 灵动岛小组件主体：把宠物状态渲染到锁屏 / 灵动岛
/// 注意：这是「卡片式」显示——小图标 + 文字，不做动画、不常驻（系统规则）
struct PetIslandWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PetActivityAttributes.self) { context in
            // ---- 锁屏 / 展开卡片 ----
            HStack(spacing: 12) {
                PixelPetIcon(emoji: context.state.emoji, size: 44)
                VStack(alignment: .leading, spacing: 2) {
                    Text(context.state.petName)
                        .font(.headline)
                    Text("❤️ \(context.state.love)  \(context.state.action)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Spacer()
            }
            .padding(16)
        } dynamicIsland: { context in
            // ---- 灵动岛（iPhone 14 Pro 及以后）----
            DynamicIsland {
                // 展开状态
                DynamicIslandExpandedRegion(.leading) {
                    PixelPetIcon(emoji: context.state.emoji, size: 40)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing, spacing: 1) {
                        Text(context.state.petName)
                            .font(.footnote.weight(.medium))
                        Text("❤️ \(context.state.love)")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text(context.state.action)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            } compactLeading: {
                // 收起的小胶囊（左侧：宠物小头像）
                PixelPetIcon(emoji: context.state.emoji, size: 20)
            } compactTrailing: {
                // 收起的小胶囊（右侧：爱心值）
                Text("❤️\(context.state.love)")
                    .font(.caption2)
            } minimal: {
                // 极简（多活动并存时）
                PixelPetIcon(emoji: context.state.emoji, size: 18)
            }
        }
    }
}
