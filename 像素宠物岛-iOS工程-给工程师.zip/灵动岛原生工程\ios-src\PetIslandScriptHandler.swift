import UIKit
import ActivityKit
import WebKit

/// 接收网页发来的消息（喂食/玩耍/升级…），实时更新灵动岛上的宠物
/// 网页端调用：window.webkit.messageHandlers.petIsland.postMessage({...})
class PetIslandScriptHandler: NSObject, WKScriptMessageHandler {

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage
    ) {
        guard message.name == "petIsland",
              let body = message.body as? [String: Any] else { return }

        let type = body["type"] as? String ?? ""
        let petName = body["petName"] as? String ?? "宠物"
        let emoji = body["emoji"] as? String ?? "🐱"
        let love = body["love"] as? Int ?? 0
        let action = body["action"] as? String ?? ""

        switch type {
        case "start":
            PetActivityBridge.start(petName: petName, emoji: emoji, love: love, action: action)
        case "update":
            PetActivityBridge.update(petName: petName, emoji: emoji, love: love, action: action)
        case "end":
            PetActivityBridge.end()
        default:
            break
        }
    }
}

/// 对苹果「实时活动」(ActivityKit) 的封装：启动 / 更新 / 结束
/// 需要 iOS 16.1+，且必须真机（模拟器不支持灵动岛）
enum PetActivityBridge {

    static func start(petName: String, emoji: String, love: Int, action: String) {
        guard #available(iOS 16.1, *) else { return }
        let attributes = PetActivityAttributes(petName: petName, emoji: emoji)
        let state = PetActivityAttributes.ContentState(petName: petName, emoji: emoji, love: love, action: action)
        do {
            _ = try Activity<PetActivityAttributes>.request(
                attributes: attributes,
                contentState: state,
                pushType: nil
            )
        } catch {
            print("[宠物岛] 实时活动启动失败: \(error.localizedDescription)")
        }
    }

    static func update(petName: String, emoji: String, love: Int, action: String) {
        guard #available(iOS 16.1, *) else { return }
        Task {
            for activity in Activity<PetActivityAttributes>.activities {
                let state = PetActivityAttributes.ContentState(petName: petName, emoji: emoji, love: love, action: action)
                await activity.update(using: state)
            }
        }
    }

    static func end() {
        guard #available(iOS 16.1, *) else { return }
        Task {
            for activity in Activity<PetActivityAttributes>.activities {
                await activity.end(dismissalPolicy: .immediate)
            }
        }
    }
}
