import SwiftUI

/// 用 SwiftUI 画的「像素宠物」小头像，显示在灵动岛 / 锁屏卡片里
/// 数据是 10x8 的字符画网格：'#' = 主体色，'o' = 深色（眼睛），'.' = 透明
struct PixelPetIcon: View {
    let emoji: String
    let size: CGFloat

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.28)
                .fill(Color(red: 1.0, green: 0.87, blue: 0.92)) // 粉色底，像灵动岛胶囊
            PixelCanvas(sprite: sprite, size: size)
                .padding(size * 0.10)
        }
        .frame(width: size, height: size)
    }

    private var sprite: PixelSprite {
        if emoji.contains("❤️") || emoji.contains("💗") || emoji.contains("🧡") { return .heart }
        if emoji.contains("🐶") || emoji.contains("🐺") { return .dog }
        return .cat
    }
}

enum PixelSprite {
    case cat, dog, heart

    var grid: [String] {
        switch self {
        case .cat:
            return [
                "..#....#..",
                ".##....##.",
                "##########",
                "##o####o##",
                "##########",
                ".########.",
                "..######..",
                "..##..##.."
            ]
        case .dog:
            return [
                "..##...##.",
                ".##....##.",
                "##########",
                "#o######o#",
                "##########",
                ".########.",
                "..######..",
                "...####..."
            ]
        case .heart:
            return [
                ".####.####.",
                "##########",
                "##########",
                ".########.",
                "..######..",
                "...####...",
                "....##....",
                ".........."
            ]
        }
    }

    var body: Color { Color(red: 0.95, green: 0.52, blue: 0.30) } // 橙色主体
    var dark: Color { Color(red: 0.30, green: 0.16, blue: 0.12) }  // 深色眼睛
}

struct PixelCanvas: View {
    let sprite: PixelSprite
    let size: CGFloat

    var body: some View {
        Canvas { ctx, box in
            let cols = sprite.grid[0].count
            let rows = sprite.grid.count
            let cell = box.width / CGFloat(cols)
            let yOff = (box.height - CGFloat(rows) * cell) / 2
            for (r, row) in sprite.grid.enumerated() {
                for (c, ch) in row.enumerated() {
                    guard ch != "." else { continue }
                    let rect = CGRect(
                        x: CGFloat(c) * cell,
                        y: yOff + CGFloat(r) * cell,
                        width: cell,
                        height: cell
                    )
                    ctx.fill(Path(rect), with: .color(ch == "o" ? sprite.dark : sprite.body))
                }
            }
        }
    }
}
